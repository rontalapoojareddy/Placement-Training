void main()
{
	if(printf("%d",1))
	printf("test bye");
	else
	printf("baby");
	return 10;
}
