main()
{
	int a=12;
	if(a&1==1)
	{
		printf("odd");
	}
	else
	{
		printf("even");
	}
}
