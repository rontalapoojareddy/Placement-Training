// print the lonely integers in an array

main()
{
	int a[]={10,20,30,20,10,35,30};
	int res=0,i=0;
	for(i=0;i<8;i++)
	{
		res=res^a[i];
	}	
	printf("%d",res);
	
}
