main()
{
	int a=~100;
	printf("%d",a);
}
