union orange
{
	int a[201];
	double b[102];
	char c[804];
}o1,o2;
main()
{
	printf("Size of Orange = %d",sizeof(o1));
}
