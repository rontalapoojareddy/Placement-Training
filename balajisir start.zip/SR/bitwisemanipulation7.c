// determine a number is power of 2 or not
// Class work: determine a number is power of 4 or not








main()
{
	int count=0,n=32;
	while(n)
	{
		count++;
		n=n&(n-1);
	}
	if(count==1)
	{
		printf("true");
	}else
	{
		printf("false");
	}
	
}
