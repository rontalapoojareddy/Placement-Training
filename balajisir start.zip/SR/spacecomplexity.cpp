main()
{
	int mobile=9842098420;
	printf("My mobile =%d",mobile);
}
