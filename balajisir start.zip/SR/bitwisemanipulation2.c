main()
{
	int a=2,b=,res=1;
	while(a && b)
	{
		if(a&1==1)
		{
		if(b&1==1)
		res=res*2;	
		}	
		a=a>>1;
		b=b>>1;
	}
	printf("result =%d",res);
	
}
