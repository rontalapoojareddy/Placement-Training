main()
{
	long long int mobile=9842098420;
	printf("My mobile =%lld\n",mobile);
	
	long long int adhar=123456789012;
	printf("My adhar=%lld\n",adhar);
	
	int pincode=636007;
	printf("my pincode=%i\n",pincode);
	
	short age=50;
	printf("My age=%hi\n",age);
}
