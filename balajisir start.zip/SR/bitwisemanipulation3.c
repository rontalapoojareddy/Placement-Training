/*smallest number greater than 'n' with 
exactly 1 bit diff in binary form*/

main()
{
	int a=31;
	printf("%d",a | a+1);
}
