// how many bits need to represnt the number 'n'?
main()
{
	int count=0,a=4;
	while(a>0)
	{
		count++;
		a=a/2;
	}
	printf("count=%d",count);
}
