main()
{
	int a=15,count=0;
/*	while(a>0)
	{
		if(a&1)
		{
			count++;
		}
		a=a>>1;
	}
	printf("count set bits =%d",count);
	
	OR
	
	*/
	while(a)
	{
		count++;
		a=a&(a-1);
	}
	printf("count set bits =%d",count);
	 
}
