main()
{
	int a=10;
	int bit=floor(log2(a)+1);
	int res=1<<(bit-1);
	res=res|res-1;
	printf("%d",a^res);
}
