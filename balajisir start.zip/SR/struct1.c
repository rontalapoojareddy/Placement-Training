struct Apple
{
	int a[400];//400*4=1600
	double b;//8
	char c[777];//777+1
}a1,a2;
main()
{
	printf("size of Apple is %d ",sizeof(a1));
}
