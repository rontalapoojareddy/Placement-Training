struct apple
{
	int a[103];
	double b[3000];
	char c[1999];
}s1,s2,s3;
main()
{
	printf("sizeof apple=%d",sizeof(s1));
}

//shivakrishnabeeraboina@gmail.com
//sahithikanjarla5@gmail.com
